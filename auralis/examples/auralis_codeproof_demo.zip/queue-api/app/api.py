def create_booking_route(payload, service):
    if not payload.get("slot_id"):
        raise ValueError("slot_id missing")
    return service.reserve_slot(payload["slot_id"], payload["user_id"])
