"""Synthetic concurrency case for interview practice. Not production code."""
def reserve_slot(slot, user_id, db):
    if slot.available:
        db.save_booking(slot.id, user_id)
        slot.available = False
        return {"status":"reserved"}
    return {"status":"full"}

